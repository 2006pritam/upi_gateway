<?php

return [
    // Minutes a payment link stays valid before the order expires.
    'order_expiry_minutes' => (int) env('GATEWAY_ORDER_EXPIRY_MINUTES', 15),

    // Minimum seconds between two provider status checks for the same order.
    'check_interval_seconds' => 3,

    // Unofficial Paytm for Business status endpoint. It may change without notice.
    'paytm_status_url' => env('PAYTM_STATUS_URL', 'https://securegw.paytm.in/merchant-status/getTxnStatus'),

    // Official PhonePe PG (Standard Checkout v2).
    'phonepe_pg' => [
        'sandbox' => [
            'token_url' => 'https://api-preprod.phonepe.com/apis/pg-sandbox/v1/oauth/token',
            'base_url' => 'https://api-preprod.phonepe.com/apis/pg-sandbox',
        ],
        'production' => [
            'token_url' => 'https://api.phonepe.com/apis/identity-manager/v1/oauth/token',
            'base_url' => 'https://api.phonepe.com/apis/pg',
        ],
    ],

    // Official Paytm Payment Gateway.
    'paytm_pg' => [
        'sandbox' => env('PAYTM_PG_SANDBOX_URL', 'https://securestage.paytmpayments.com'),
        'production' => env('PAYTM_PG_PRODUCTION_URL', 'https://secure.paytmpayments.com'),
    ],

    // ── Webhook SSRF protection ───────────────────────────────────────────────
    // Allow http:// webhook URLs (for local dev only). Defaults to false.
    'webhook_allow_insecure' => env('GATEWAY_WEBHOOK_ALLOW_INSECURE', false),
    // Ports that webhook URLs may use. 443 always included; add 80 if insecure allowed.
    'webhook_allowed_ports' => [443],

    // ── Redirect URL security ─────────────────────────────────────────────────
    // Allow http:// redirect URLs (for local dev only). Defaults to false.
    'allow_insecure_redirects' => env('GATEWAY_ALLOW_INSECURE_REDIRECTS', false),

    // ── Content-Security-Policy ───────────────────────────────────────────────
    // Set to true to switch from Report-Only to enforcing CSP.
    // See App\Http\Middleware\SecurityHeaders for what must be fixed first.
    // Set to false to switch to Content-Security-Policy-Report-Only mode.
    'csp_enforce' => env('GATEWAY_CSP_ENFORCE', true),

    // ── API rate limiting ─────────────────────────────────────────────────────
    // Per-API-key request limit per minute. Lower this in tests via config([...]).
    'api_key_rate_limit' => (int) env('GATEWAY_API_KEY_RATE_LIMIT', 120),

    // Per-IP request limit per minute across all API keys.
    'api_ip_rate_limit' => (int) env('GATEWAY_API_IP_RATE_LIMIT', 600),

    // ── Unique payable amounts ────────────────────────────────────────────────
    // For e-mail verified accounts (the payer's bank only shows an amount), open orders for the same
    // price get +₹0.01, +₹0.02 ... so every payment maps to exactly one order.
    'unique_amount' => [
        'enabled' => (bool) env('GATEWAY_UNIQUE_AMOUNT', true),
        'providers' => ['fam_email', 'fampay_email'],
        'max_offset_paise' => (int) env('GATEWAY_UNIQUE_AMOUNT_MAX_PAISE', 50),
        'grace_minutes' => 60,   // keep an expired order's amount reserved while it can still be paid
    ],

    // ── FamApp e-mail verification ────────────────────────────────────────────
    'fam_email' => [
        // Only mail from this address, with an SPF/DKIM/DMARC pass for this domain, counts.
        'sender' => env('GATEWAY_FAM_EMAIL_SENDER', 'no-reply@famapp.in'),
        'domain' => env('GATEWAY_FAM_EMAIL_DOMAIN', 'famapp.in'),
        // E-mails older than this are ignored.
        'max_age_hours' => 72,
        // Orders that expired less than this many minutes ago can still be paid by e-mail.
        'late_grace_minutes' => 60,
        // A payment may be dated this many minutes before the order was created.
        'clock_skew_minutes' => 2,
        // Allowed age of a signed ingest request.
        'signature_tolerance_seconds' => 300,
    ],

];
