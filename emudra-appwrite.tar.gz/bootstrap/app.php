<?php

use App\Http\Middleware\AuthenticateApiKey;
use App\Http\Middleware\EnsureActive;
use App\Http\Middleware\EnsureAdmin;
use App\Http\Middleware\RedirectToInstall;
use App\Http\Middleware\SecurityHeaders;
use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;
use Illuminate\Http\Request;
use Illuminate\Session\Middleware\AuthenticateSession;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        api: __DIR__.'/../routes/api.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware): void {
        $middleware->alias([
            'admin' => EnsureAdmin::class,
            'active' => EnsureActive::class,
            'api.key' => AuthenticateApiKey::class,
        ]);

        // AuthenticateSession invalidates sessions when the user's password hash
        // changes, covering password changes AND API-key regeneration (which
        // touches the password column to bump the hash seen by the middleware).
        // It must come AFTER StartSession and AFTER Auth middleware.
        $middleware->web(prepend: [
            RedirectToInstall::class,
        ], append: [
            AuthenticateSession::class,
            SecurityHeaders::class,
        ]);

        $middleware->api(prepend: [
            RedirectToInstall::class,
        ]);

        $middleware->redirectUsersTo('/dashboard');

        // Paytm PG POSTs the customer back here from its own domain.
        $middleware->validateCsrfTokens(except: ['pay/*/return']);
    })
    ->withExceptions(function (Exceptions $exceptions): void {
        $exceptions->shouldRenderJsonWhen(
            fn (Request $request) => $request->is('api/*') || $request->expectsJson()
        );
    })->create();
